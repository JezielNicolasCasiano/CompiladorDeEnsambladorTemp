package jeziel.compiladordeensamblador.modelo;

import jeziel.compiladordeensamblador.modelo.lexer.Token;
import jeziel.compiladordeensamblador.modelo.semantico.LineaAnalizadaSemanticamente;

public class FilaTablaMaquina {
    private final String linea;
    private final String resultado;
    private final String direccion;

    public FilaTablaMaquina(String linea, String resultado, String direccion) {
        this.linea = linea;
        this.resultado = resultado;
        this.direccion = direccion;
    }

    public String getLinea() {
        return linea;
    }

    public String getResultado() {
        return resultado;
    }

    public String getDireccion() {
        return direccion;
    }

    private static String binarioAHex(String binario) {
        if (binario == null || binario.trim().isEmpty() || binario.startsWith("ERROR")) {
            return binario;
        }
        String[] partes = binario.trim().split("\\s+");
        StringBuilder sb = new StringBuilder();
        for (String parte : partes) {
            try {
                int val = Integer.parseInt(parte, 2);
                sb.append(String.format("%02X", val)).append(" ");
            } catch (NumberFormatException e) {
                sb.append(parte).append(" ");
            }
        }
        return sb.toString().trim();
    }

    public static FilaTablaMaquina crearDesdeLineaSemantica(LineaAnalizadaSemanticamente lineaSemantica) {
        StringBuilder sb = new StringBuilder();
        if (lineaSemantica.getLineaAnalizada() != null && lineaSemantica.getLineaAnalizada().getTokens() != null) {
            for (Token t : lineaSemantica.getLineaAnalizada().getTokens()) {
                sb.append(t.getValue()).append(" ");
            }
        }
        String lineaStr = sb.toString().trim();

        String resultado = "Correcta";
        if (lineaSemantica.getLineaAnalizada() != null && lineaSemantica.getLineaAnalizada().tieneError()) {
            resultado = lineaSemantica.getLineaAnalizada().getErrorSintactico().getMensajeError();
        } else if (lineaSemantica.getErrorSemantico() != null) {
            resultado = lineaSemantica.getErrorSemantico().getMensajeError();
        } else if (lineaSemantica.getCodigoMaquina() != null) {
            resultado = binarioAHex(lineaSemantica.getCodigoMaquina());
        }

        String direccion = lineaSemantica.getDireccion() != null ? lineaSemantica.getDireccion() : "";
        if (direccion != null && !direccion.equals("-") && !direccion.trim().isEmpty()) {
            direccion = direccion + "h";
        }
        return new FilaTablaMaquina(lineaStr, resultado, direccion);
    }
}
